CREATE TABLE Website
(
    WebsiteID INT IDENTITY(1,1) PRIMARY KEY,
    WebsiteName NVARCHAR(255) NOT NULL,
    WebsiteURL NVARCHAR(255) NOT NULL,
    RSSFeedURL NVARCHAR(255)
);

CREATE TABLE Article
(
    ArticleID INT IDENTITY(1,1) PRIMARY KEY,
    WebsiteID INT NOT NULL,
    Title NVARCHAR(255) NOT NULL,
    Author NVARCHAR(255),
    PublishDate DATETIME2,
    ArticleURL NVARCHAR(255) NOT NULL,
    Language NVARCHAR(50),
    Content NVARCHAR(MAX) NOT NULL,
    FOREIGN KEY (WebsiteID) REFERENCES Website(WebsiteID)
);

CREATE TABLE ArticleSummary
(
    SummaryID INT IDENTITY(1,1) PRIMARY KEY,
    ArticleID INT NOT NULL,
    SummaryText NVARCHAR(MAX) NOT NULL,
    FOREIGN KEY (ArticleID) REFERENCES Article(ArticleID)
);

CREATE TABLE Category
(
    CategoryID INT IDENTITY(1,1) PRIMARY KEY,
    CategoryName NVARCHAR(255) NOT NULL
);

CREATE TABLE ArticleCategory
(
    ArticleCategoryID INT IDENTITY(1,1) PRIMARY KEY,
    ArticleID INT NOT NULL,
    CategoryID INT NOT NULL,
    FOREIGN KEY (ArticleID) REFERENCES Article(ArticleID),
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
);

CREATE TABLE Statistic
(
    StatisticID INT IDENTITY(1,1) PRIMARY KEY,
    Date DATE NOT NULL,
    ArticlesDownloaded INT NOT NULL,
    ExecutionTime INT NOT NULL,
    OpenAITokenConsumption DECIMAL(10,2) NOT NULL
);