from sqlalchemy import create_engine, Table, Column, Integer, String, MetaData
from loguru import logger
from dotenv import load_dotenv
import os

load_dotenv()

class DatabaseManager:
    def __init__(self):
        self.database_url = os.getenv("DATABASE_URL")
        self.engine = create_engine(self.database_url)
        self.metadata = MetaData()
        self.articles = Table('articles', self.metadata,
            Column('id', Integer, primary_key=True),
            Column('title', String),
            Column('summary', String),
            Column('language', String),
            Column('category', String),
        )
    
    def create_table(self):
        self.metadata.create_all(self.engine)
    
    def insert_article(self, article_data):
        with self.engine.connect() as conn:
            conn.execute(self.articles.insert(), article_data)
            logger.info("Article data inserted into database")