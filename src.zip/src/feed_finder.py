from bs4 import BeautifulSoup as bs4  
import requests  
import feedparser  
import urllib.parse  
from loguru import logger  
  
class FeedFinder:  
    def __init__(self, site):  
        self.site = site  
        logger.info(f"Initialized FeedFinder for site: {self.site}")  
      
    def find_feeds(self):  
        try:  
            logger.info(f"Fetching content from: {self.site}")  
            response = requests.get(self.site)  
            response.raise_for_status()  
            raw = response.text  
        except requests.RequestException as e:  
            logger.error(f"Error fetching the site: {e}")  
            return []  
  
        result = []  
        possible_feeds = []  
        html = bs4(raw, 'html.parser')  
          
        # Find feed URLs in link tags  
        logger.debug("Searching for feed URLs in link tags")  
        feed_urls = html.findAll("link", rel="alternate")  
        for f in feed_urls:  
            t = f.get("type", None)  
            if t and ("rss" in t or "xml" in t):  
                href = f.get("href", None)  
                if href:  
                    possible_feeds.append(urllib.parse.urljoin(self.site, href))  
          
        # Parse base URL  
        parsed_url = urllib.parse.urlparse(self.site)  
        base = parsed_url.scheme + "://" + parsed_url.hostname  
          
        # Find feed URLs in anchor tags  
        logger.debug("Searching for feed URLs in anchor tags")  
        atags = html.findAll("a")  
        for a in atags:  
            href = a.get("href", None)  
            if href and ("xml" in href or "rss" in href or "feed" in href):  
                possible_feeds.append(urllib.parse.urljoin(self.site, href))  
          
        # Validate and collect unique feed URLs  
        logger.debug("Validating and collecting feed URLs")  
        for url in list(set(possible_feeds)):  
            f = feedparser.parse(url)  
            if len(f.entries) > 0:  
                result.append(url)  
                logger.info(f"Valid feed found: {url}")  
          
        if not result:  
            logger.warning("No valid feeds found.")  
          
        return result  
