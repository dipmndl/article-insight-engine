class StatisticsCollector:
    def __init__(self):
        # Initialize your stats structure here
        pass
      
    # Methods to update and report stats go here.