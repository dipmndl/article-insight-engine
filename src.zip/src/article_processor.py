import os  
from openai import AzureOpenAI
from azure.identity import DefaultAzureCredential  
from azure.keyvault.secrets import SecretClient  
from loguru import logger  
  
class ArticleProcessor:  
    def __init__(self):  
        # Setting up Azure Key Vault  
        key_vault_name = os.environ["KEY_VAULT_NAME"]  
        key_vault_uri = f"https://{key_vault_name}.vault.azure.net/"  
  
        # DefaultAzureCredential will first look for Azure CLI or Visual Studio Code credentials.  
        # Next, it will look for environment variables,  
        # and finally, it will attempt to use managed identity if available.  
        credential = DefaultAzureCredential()  
        secret_client = SecretClient(vault_url=key_vault_uri, credential=credential)  
  
        # Fetch the OpenAI key from Azure Key Vault  
        secret_name = os.environ["OPENAI_SECRET_NAME"]  
        retrieved_secret = secret_client.get_secret(secret_name)  

        self.client = AzureOpenAI(
            api_key = retrieved_secret.value,
            # https://learn.microsoft.com/en-us/azure/ai-services/openai/reference#rest-api-versioning
            api_version=os.environ["OPENAI_API_VERSION"],
            # https://learn.microsoft.com/en-us/azure/cognitive-services/openai/how-to/create-resource?pivots=web-portal#create-a-resource
            azure_endpoint=os.environ["OPENAI_ENDPOINT"]
        )
  
    def detect_language(self, text):  
        logger.info("Detect the language")
        try:  
            response = self.client.chat.completions.create(
                model=os.environ["OPENAI_MODEL"],                
                messages=[  
                    {"role": "system", "content": "You are a helpful assistant that recognize the language of a text. The output will be only the language detected in the short form (eg. EN, IT, etc)."},  
                    {"role": "user", "content": "What is the language of following text?" + text}  
                ]
            )                          
            #print(response.model_dump_json(indent=2))
            return response.choices[0].message.content
        except Exception as e:  
            logger.error(f"Language detection failed: {e}")  
            return "Unknown"  
      
    def translate(self, text, language):  
        logger.info("Translate")
        try:  
            response = self.client.chat.completions.create(
                model=os.environ["OPENAI_MODEL"],                
                messages=[  
                    {"role": "system", "content": "You are a helpful assistant that translate text. The output will be only the translated text."},  
                    {"role": "user", "content": "Translate following text in " + language + ":" + text}  
                ]
            )                          
            #print(response.model_dump_json(indent=2))
            return response.choices[0].message.content
        except Exception as e:  
            logger.error(f"Translate failed: {e}")  
            return "Unknown"
      
    def create_summary(self, article):  
        logger.info("Summarize the article")
        try:  
            response = self.client.chat.completions.create(
                model=os.environ["OPENAI_MODEL"],                
                messages=[  
                    {"role": "system", "content": "You are a helpful assistant that summarize the article. The output will be the summary of the article."},  
                    {"role": "user", "content": "What is the summary for this article?" + article}  
                ]
            )                          
            #print(response.model_dump_json(indent=2))
            return response.choices[0].message.content
        except Exception as e:  
            logger.error(f"Summary creation failed: {e}")  
            return "Unknown"  
      
    def categorize_article(self, summary, categories):  
        logger.info("Categorize the article")
        try:  
            response = self.client.chat.completions.create(
                model=os.environ["OPENAI_MODEL"],                
                messages=[  
                    {"role": "system", "content": "You are a helpful assistant that categorize the article based on a list of categories. The output will be the category of the article."},  
                    {"role": "user", "content": "What is the category for this article?" + summary + " Here are the categories: " + ", ".join(categories)}  
                ]
            )                          
            #print(response.model_dump_json(indent=2))
            return response.choices[0].message.content
        except Exception as e:  
            logger.error(f"Category detection failed: {e}")  
            return "Unknown"  
  
# Usage example  
if __name__ == "__main__":  
    processor = ArticleProcessor()  
    language = processor.detect_language("This is an English text.")  
    print(f"Detected language: {language}")