import requests
from lxml import html
from loguru import logger
import urllib.parse
import re
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import newspaper

class FeedFinder2:
    def __init__(self, url):
        self.url = url
        logger.info(f"Initialized FeedFinder for URL: {self.url}")

    def find_feed(self):
        try:
            logger.info(f"Finding feeds from: {self.url}")
            response = requests.get(self.url, headers={'User-Agent': 'Mozilla/5.0'})
            if response.status_code != 200:
                logger.error(f"Failed to fetch URL: {self.url} with status code: {response.status_code}")
                return []

            html_content = response.content
            tree = html.fromstring(html_content)
            base_url = self.url

            # Find RSS links in <head>
            rss_links = tree.xpath("//link[@rel='alternate'][@type='application/rss+xml']/@href")
            rss_links += tree.xpath("//link[@rel='alternate'][@type='application/atom+xml']/@href")

            # Find RSS links in <body>
            body_links = tree.xpath("//a[contains(translate(@href, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'rss')]/@href")
            rss_links += body_links

            # Additional checks for RSS links in meta tags and script tags
            meta_links = tree.xpath("//meta[contains(@content, 'rss')]/@content")
            rss_links += meta_links

            script_links = tree.xpath("//script[contains(text(), 'rss')]/text()")
            for script in script_links:
                rss_links += re.findall(r'(https?://\S+\.rss)', script)

            # Normalize URLs
            rss_links = [urllib.parse.urljoin(base_url, link.strip()) for link in rss_links]

            # Follow found RSS links to check for additional RSS links
            all_rss_links = set(rss_links)
            for rss_link in rss_links:
                additional_links = self._find_additional_rss_links(rss_link)
                all_rss_links.update(additional_links)

            if all_rss_links:
                logger.info(f"Found {len(all_rss_links)} RSS links")
            else:
                logger.warning("No RSS links found")

            return list(all_rss_links)

        except requests.RequestException as e:
            logger.error(f"Failed to fetch URL: {self.url} with error: {e}")
            return []
        except Exception as e:
            logger.error(f"Error finding RSS links: {e}")
            return []

    def _find_additional_rss_links(self, rss_url):
        try:
            logger.info(f"Checking for additional RSS links in: {rss_url}")
            response = requests.get(rss_url, headers={'User-Agent': 'Mozilla/5.0'})
            if response.status_code != 200:
                logger.error(f"Failed to fetch URL: {rss_url} with status code: {response.status_code}")
                return []

            html_content = response.content
            tree = html.fromstring(html_content)
            base_url = rss_url

            # Find RSS links in <head>
            rss_links = tree.xpath("//link[@rel='alternate'][@type='application/rss+xml']/@href")
            rss_links += tree.xpath("//link[@rel='alternate'][@type='application/atom+xml']/@href")

            # Find RSS links in <body>
            body_links = tree.xpath("//a[contains(translate(@href, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'rss')]/@href")
            rss_links += body_links

            # Normalize URLs
            rss_links = [urllib.parse.urljoin(base_url, link.strip()) for link in rss_links]

            return rss_links

        except requests.RequestException as e:
            logger.error(f"Failed to fetch URL: {rss_url} with error: {e}")
            return []
        except Exception as e:
            logger.error(f"Error finding additional RSS links: {e}")
            return []
    ''' 
    def extract_articles_from_html(self):  
        try:  
            logger.info(f"Extracting articles from HTML: {self.url}")  
            response = requests.get(self.url, headers={'User-Agent': 'Mozilla/5.0'})  
            if response.status_code != 200:  
                logger.error(f"Failed to fetch URL: {self.url} with status code: {response.status_code}")  
                return []  
    
            html_text = response.text  
            soup = BeautifulSoup(html_text, 'lxml')  
    
            # Lista dei possibili selettori  
            selectors = [  
                {'tag': 'article', 'class': 'listing-item-blog'},  
                {'tag': 'div', 'class': 'news-item'},  
                {'tag': 'article', 'class': 'post'},  
                {'tag': 'div', 'class': 'article'},  
                # Aggiungi altri selettori se necessario  
            ]  
    
            news_container = []  
            for selector in selectors:  
                news_container = soup.find_all(selector['tag'], class_=selector['class'])  
                if news_container:  
                    break  # Esce dal ciclo se trova articoli  
    
            articles = []  
            prev_publish_date = None  # Memorizza la data di pubblicazione precedente  
    
            for each_news in news_container:  
                try:  
                    new_subpage = each_news.find('a', class_="post-title post-url")['href']  
                    subpage_html = requests.get(new_subpage).text  
                    subpage_soup = BeautifulSoup(subpage_html, 'lxml')  
    
                    news_title = subpage_soup.find('span', class_="post-title").text  
                    news_publish_date_element = each_news.find('time', class_="post-published updated")  
                    news_publish_date = news_publish_date_element['datetime']  
    
                    if prev_publish_date and news_publish_date > prev_publish_date:  
                        continue  # Salta la news se la data non è maggiore della precedente  
    
                    div_element = subpage_soup.find('div', class_='entry-content clearfix single-post-content')  
                    p_elements = div_element.find_all('p')  
                    paragraphs = [p.get_text(strip=True).replace('�', '') for p in p_elements]  
    
                    # Estrai l'URL dell'immagine  
                    image_element = subpage_soup.find('a', class_="post-thumbnail open-lightbox")  
                    image_url = image_element['href'] if image_element else None  
    
                    article_data = {  
                        'title': news_title,  
                        'publish_date': news_publish_date,  
                        'paragraphs': paragraphs,  
                        'image': image_url,  
                        'link': new_subpage,  
                        'language': None,  
                        'text': None,  
                        'category': None  
                    }  
    
                    articles.append(article_data)  
    
                except Exception as e:  
                    logger.error(f"Error processing article: {e}")  
    
            # Aggiorna la data di pubblicazione precedente  
            if articles:  
                prev_publish_date = articles[-1]['publish_date']  
    
            return articles  
    
        except requests.RequestException as e:  
            logger.error(f"Failed to fetch URL: {self.url} with error: {e}")  
            return []  
        except Exception as e:  
            logger.error(f"Error extracting articles from HTML: {e}")  
            return []  
     '''
    def extract_articles_from_html(self):
        url = 'https://www.nytimes.com/live/2021/10/25/us'
        article = newspaper.Article(url=url, language='en')
        article.download()
        article.parse()

        article ={
            "title": str(article.title),
            "text": str(article.text),
            "authors": article.authors,
            "published_date": str(article.publish_date),
            "top_image": str(article.top_image),
            "videos": article.movies,
            "keywords": article.keywords,
            "summary": str(article.summary)
        }
        print(article["title"] \
            + "\n\t\t" + article["published_date"] \
            + "\n\n"\
            + "\n" + article["text"]\
            + "\n\n")