import feedparser
from loguru import logger
import requests

class ArticleExtractor:
    def __init__(self):
        logger.info("ArticleExtractor initialized")

    def extract_articles(self, rss_url):
        logger.info(f"Extracting articles from RSS URL: {rss_url}")
        try:
            response = requests.get(rss_url)
            response.raise_for_status()
            content = response.content

            # Decode content to handle non-latin characters
            encoding = response.encoding if response.encoding else 'utf-8'
            content = content.decode(encoding)

            # Parse the feed content
            feed = feedparser.parse(content)
            if feed.bozo:
                logger.error(f"Error parsing feed: {feed.bozo_exception}")
                return []

            articles = [
                {"title": entry.title, "link": entry.link, "summary": entry.summary}
                for entry in feed.entries
            ]
            num_articles = len(articles)
            if num_articles > 0:
                logger.info(f"Number of articles found: {num_articles}")
            else:
                logger.info("No articles found")
            return articles
        except requests.RequestException as e:
            logger.error(f"Failed to fetch articles from {rss_url}: {e}")
            return []
        except Exception as e:
            logger.error(f"Failed to parse feed content: {e}")
            return []